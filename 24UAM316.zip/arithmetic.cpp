#include<iostream>
using namespace std;
int main()
{
	int num1,num2,add,sub,mul,div;
	cout<<"Enter two values : ";
	cin>>num1>>num2;
	
	add=num1+num2;
	sub=num1-num2;
	mul=num1*num2;
	div=num1/num2;
	
	cout<<"Addition = "<<add<<endl;
	cout<<"Substraction = "<<sub<<endl;
	cout<<"Multiplication = "<<mul<<endl;
	cout<<"Division = "<<div<<endl;
	return 0;
}
